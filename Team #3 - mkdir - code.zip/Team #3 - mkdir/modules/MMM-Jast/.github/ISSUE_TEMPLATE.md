Platform (Hardware/OS):

Node version:

MagicMirror version:

Module version:

Description of the issue:
