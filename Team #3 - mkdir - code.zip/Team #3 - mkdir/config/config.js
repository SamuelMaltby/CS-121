/* Magic Mirror Config Sample
 *
 * By Michael Teeuw https://michaelteeuw.nl
 * MIT Licensed.
 *
 * For more information on how you can configure this file
 * See https://github.com/MichMich/MagicMirror#configuration
 *
 */

var config = {
	address: "localhost", 	// Address to listen on, can be:
							// - "localhost", "127.0.0.1", "::1" to listen on loopback interface
							// - another specific IPv4/6 to listen on a specific interface
							// - "0.0.0.0", "::" to listen on any interface
							// Default, when address config is left out or empty, is "localhost"
	port: 8080,
	basePath: "/", 	// The URL path where MagicMirror is hosted. If you are using a Reverse proxy
					// you must set the sub path here. basePath must end with a /
	ipWhitelist: ["127.0.0.1", "::ffff:127.0.0.1", "::1"], 	// Set [] to allow all IP addresses
															// or add a specific IPv4 of 192.168.1.5 :
															// ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:192.168.1.5"],
															// or IPv4 range of 192.168.3.0 --> 192.168.3.15 use CIDR format :
															// ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:192.168.3.0/28"],

	useHttps: false, 		// Support HTTPS or not, default "false" will use HTTP
	httpsPrivateKey: "", 	// HTTPS private key path, only require when useHttps is true
	httpsCertificate: "", 	// HTTPS Certificate path, only require when useHttps is true

	language: "en",
	locale: "en-US",
	logLevel: ["INFO", "LOG", "WARN", "ERROR"], // Add "DEBUG" for even more logging
	timeFormat: 12,
	units: "imperial",
	// serverOnly:  true/false/"local" ,
	// local for armv6l processors, default
	//   starts serveronly and then starts chrome browser
	// false, default for all NON-armv6l devices
	// true, force serveronly mode, because you want to.. no UI on this device

	modules: [
		{
			module: "alert",
		},
		{
			module: "updatenotification",
			position: "top_bar"
		},
		{
			module: "clock",
			position: "top_left"
		},
		/*{
			module: "MMM-JokeAPI",
			position: "bottom_bar",
			config: {
			    category: "Programming"
			}
		},*/
		{
			module: "calendar_monthly",
			position: "top_center",
			config: {
				maxWidth: "100%",
			}
		},
		{
			module: "MMM-MovieInfo",
			position: "bottom_left",
			config: {
				api_key: "8c504e8c08589c3fc7c0ef03e7896a76",
			
			discover: {
				"sort_by": "popularity.desc"
			}}
		},
		{
			
            		module: 'MMM-OnThisDay',
            		position: "bottom_right", // All available positions
            		config: {
                	// See below for configurable options, this is optional
            		}
        
		},
		{
			module: "MMM-Jast",
			position: "bottom_bar",
			config: {
				maxWidth: "100%",
				updateIntervalInSeconds: 300,
				fadeSpeedInSeconds: 60.0, // Higher value: vertical -> faster // horizontal -> slower
				scroll: "horizontal", // One of ["none", "vertical", "horizontal"]
				useGrouping: false,
				currencyStyle: "code", // One of ["code", "symbol", "name"]
				showColors: true,
				showCurrency: true,
				showChangePercent: true,
				showChangeValue: false,
				showChangeValueCurrency: false,
				showDepot: false,
				showDepotGrowthPercent: false,
				showDepotGrowth: false,
				numberDecimalsValues: 2,
				numberDecimalsPercentages: 1,
				stocks: [
					{ name: "BASF", symbol: "BAS.DE", quantity: 10 },
					{ name: "SAP", symbol: "SAP.DE", quantity: 15 },
					{ name: "Henkel", symbol: "HEN3.DE" },
					{ name: "Alibaba", symbol: "BABA"},
					{ name: "Apple", symbol: "AAPL"},
					{ name: "Google", symbol: "GOOGL"},
					{ name: "Twitter", symbol: "TWTR"},
					{ name: "Activision", symbol: "ATVI"},
					{ name: "Verizon", symbol: "VZ"},
					{ name: "Visa", symbol: "V"},
					{ name: "NIO", symbol: "NIO"},
					{ name: "Etsy", symbol: "ETSY"},
					{ name: "Moderna", symbol: "MRNA"},
					{ name: "Square", symbol: "SQ"},
					{ name: "Delta", symbol: "DAL"},
					{ name: "Southwest", symbol: "LUV"},
					{ name: "United", symbol: "UAL"}
				]
			}
		},
		{
			module: "weather",
			position: "top_right",
			config: {
				weatherProvider: "openweathermap",
				type: "current",
				location: "Burlington, VT",
				locationID: "5234372", //ID from http://bulk.openweathermap.org/sample/city.list.json.gz; unzip the gz file and find your city
				apiKey: "012157464c128d4223ec931983c51ee0"
			}
		},
		{
			module: "weather",
			position: "top_right",
			header: "Weather Forecast",
			config: {
				weatherProvider: "openweathermap",
				type: "forecast",
				location: "Burlington, VT",
				locationID: "5234372", //ID from http://bulk.openweathermap.org/sample/city.list.json.gz; unzip the gz file and find your city
				apiKey: "012157464c128d4223ec931983c51ee0"
			}
		},
		/*{
			module: "newsfeed",
			position: "bottom_bar",
			config: {
				feeds: [
					{
						title: "New York Times",
						url: "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml"
					}
				],
				showSourceTitle: true,
				showPublishDate: true,
				broadcastNewsFeeds: true,
				broadcastNewsUpdates: true
			}
		},*/
	]
};

/*************** DO NOT EDIT THE LINE BELOW ***************/
if (typeof module !== "undefined") {module.exports = config;}
